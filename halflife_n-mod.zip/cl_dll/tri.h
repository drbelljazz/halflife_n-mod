#pragma once

#include "particleman.h"

extern IParticleMan* g_pParticleMan;
